﻿using System;
using System.Windows.Forms;

namespace Troubleshoot_StatusBar
{
    public partial class FrmCompletionForm : Form
    {
        private static string _strLoc;

        public FrmCompletionForm(string strLocation, string strNotification)
        {
            InitializeComponent();            
            lblFinalNotification.Text = strNotification;
            linkLabel1.Text = strLocation;
            _strLoc = strLocation;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(_strLoc);
        }    

    }
}

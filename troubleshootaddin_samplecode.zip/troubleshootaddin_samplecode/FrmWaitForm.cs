﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using Troubleshoot_StatusBar.Properties;

namespace Troubleshoot_StatusBar
{
    public partial class FrmWaitForm : Form
    {
        public Action Worker { get; set; }                        

        public FrmWaitForm(Action worker, string initialNotification)
        {
            InitializeComponent();

            if (worker.Method.Name == "LoadTroubleshoot")
            {
                lblHeader.Text = Resources.FrmWaitForm_FrmWaitForm_Load;
                lblInitialNotification.Text = initialNotification;
            }
            else
            {
                lblHeader.Text = Resources.FrmWaitForm_FrmWaitForm_Stop;
                lblInitialNotification.Visible = false;
            }

            Worker = worker;           

        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Task.Factory.StartNew(Worker).ContinueWith(t => {
                Close();
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }
    }
}

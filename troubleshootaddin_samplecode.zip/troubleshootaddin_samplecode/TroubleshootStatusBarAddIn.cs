﻿/*
* This demo program shows how to use Desktop Add-Ins (.NET API) library to provide 
* a friendly Troubleshoot Tools embedded in your Oracle Service Cloud.
*
* You can reuse this demo code to add other needs such as Fiddler or pings.
* For more references on how to use Fiddler embedded, please visit:
* Fiddler Core Licenses: https://www.telerik.com/fiddler/fiddlercore
* Fiddler Core Demo Code: http://fiddler.wikidot.com/fiddlercore-demo
*
* This is a sample code, which doesn't include support. Please, don't open any SR to
* Tech Support, use CX Community instead.
* 
* Author: Edson Junior
* Date: 2018-03-20
* 
*/

using RightNow.AddIns.AddInViews;
using System.AddIn;
using System.Linq;
using System.Windows.Forms;

namespace Troubleshoot_StatusBar
{
    /// <inheritdoc>
    ///     <cref />
    /// </inheritdoc>
    /// <summary>
    /// creates a control that lives in the status bar of the cx console
    /// </summary>
    [AddIn("Troubleshoot StatusBar", Version = "1.0")]
    public class TroubleshootStatusBarAddIn : Panel, IStatusBarItem
    {
        private StatusBarControl _control;                       
        private static string _agentpermission;           

        /// <summary>
        /// create the control
        /// </summary>
        /// <param name="context"></param>        
        /// <returns></returns>
        public bool Initialize(IGlobalContext context)
        {

            _control = new StatusBarControl(context, WorkstationInfo, ScreenCapture, TsPath, 
                ReminderInMinutes, InitialNotification, FinalNotification);
            //Return StatusBarControl only if agent login matches with the returned list.
            char[] delimiterChars = { ';' };
            var agents = _agentpermission.Split(delimiterChars);

            return agents.Any(s => s == context.Login || s == "all" || s == "All");
        }

        [ServerConfigProperty("All")]
        public string AgentPermission
        {
            get => _agentpermission;
            set => _agentpermission = value;
        }

        [ServerConfigProperty("false")]
        public bool WorkstationInfo { get; set; }

        [ServerConfigProperty("true")]
        public bool ScreenCapture { get; set; }

        [ServerConfigProperty("")]
        public string TsPath { get; set; }

        [ServerConfigProperty("5")]
        public int ReminderInMinutes { get; set; }

        [ServerConfigProperty("Thank you. You should now see a file on the following location. Please provide this file to your Service Cloud Administrator.")]
        public string FinalNotification { get; set; }

        [ServerConfigProperty("Your friendly message in here!")]
        public string InitialNotification { get; set; }

        /// <summary>
        /// return the control
        /// </summary>
        /// <returns></returns>
        public Control GetControl()
        {
            return _control;            
        }
    }
}
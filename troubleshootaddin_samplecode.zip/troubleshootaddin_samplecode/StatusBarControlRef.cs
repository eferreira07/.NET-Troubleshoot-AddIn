﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using Troubleshoot_StatusBar.Properties;

namespace Troubleshoot_StatusBar
{
    public class StatusBarControlRef
    {
        private StatusBarControl _statusBarControl;

        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Timer timer1;

        public StatusBarControlRef(StatusBarControl statusBarControl)
        {
            InitializeComponent();
            _statusBarControl = statusBarControl;
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        public void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.StatusBarControlRef1.Dispose();
            }
            _statusBarControl.Dispose(disposing);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                btnStart.StatusBarControlRef1.Enabled = false;
                btnStop.StatusBarControlRef1.Enabled = true;

                var sitename = new Uri(StatusBarControl._osvcSitename);
                StatusBarControl._hostname = sitename.Host;

                StatusBarControl.TroubleshootDirectory();

                using (var frm = new FrmWaitForm(_statusBarControl.LoadTroubleshoot))
                {
                    frm.ShowDialog();
                }

                _statusBarControl._isActive = true;
            }
            catch (Exception ex)
            {
                _statusBarControl.GContext.LogMessage(ex.Message);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                btnStart.StatusBarControlRef1.Enabled = true;
                btnStop.StatusBarControlRef1.Enabled = false;

                using (var frm = new FrmWaitForm(StopTroubleshoot))
                {
                    frm.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                _statusBarControl.GContext.LogMessage(ex.Message);
            }            
        }

        private void StopTroubleshoot()
        {
            try
            {
                btnStop.StatusBarControlRef1.Enabled = false;
                btnStart.StatusBarControlRef1.Enabled = true;
                _statusBarControl._isActive = false;
                _statusBarControl._seconds = _statusBarControl._minutes = _statusBarControl._hours = 0;

                if (Launcher.IsScreenCap)
                    StopPsr();

                if (Launcher.IsOscInfo)
                {                    
                    Task.Factory.StartNew(() =>
                    {
                        var ocsFile = StatusBarControl._path + "\\OSvCinfo.bat"; // File downloaded in 03/20/2018.
                        if (!File.Exists(ocsFile))                                                    
                            ExtractEmbeddedResource("Troubleshoot_StatusBar", StatusBarControl._rootpath, "OSvCInfo", "OSvCinfo.bat");                        
                    }).ContinueWith(antecedent =>
                    {                        
                        RunOsvCInfo();
                    });
                }
                else
                {
                    Task.Factory.StartNew(WorkStationInfo).ContinueWith(antecedent =>
                    {
                        CompressAndNotify();
                    });                    
                }
            }
            catch (Exception e)
            {
                _statusBarControl.GContext.LogMessage(e.Message);
            }
        }

        private void StopPsr()
        {
            try
            {

                InvokeProcess(StatusBarControl.PsrExe, @"/stop").WaitForExit(60000);

                // Sleep to ensure PSR completes file creation operation
                Thread.Sleep(StatusBarControl.SaveDelay);

                if (!File.Exists(_statusBarControl._psrLogFile))
                {
                    MessageBox.Show(Resources.StatusBarControl_LoadPsr_No_user_actions_were_recorded_by_PSR_);
                }
            }
            catch (Exception e)
            {
                _statusBarControl.GContext.LogMessage(e.Message);
            }
        }

        private static Process InvokeProcess(string processName, string parameters)
        {
            var startInfo = new ProcessStartInfo(processName, parameters)
            {
                WindowStyle = ProcessWindowStyle.Hidden,
                UseShellExecute = true,
                ErrorDialog = false
            };

            var proc = new Process {StartInfo = startInfo};
            proc.Start();

            return proc;
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            if (_statusBarControl._isActive)
            {
                _statusBarControl._seconds++;

                if (_statusBarControl._seconds > 59)
                {
                    _statusBarControl._minutes++;
                    _statusBarControl._seconds = 0;
                    if (Convert.ToInt32(_statusBarControl._minutes) >= StatusBarControl._nextConfirmation)
                    {
                        StatusBarControl._nextConfirmation += Launcher.Timer;

                        var dialogResult = MessageBox.Show(Resources.StatusBarControl_timer1_Tick_1_Are_you_still_collecting_data_, Resources.StatusBarControl_timer1_Tick_1_Troubleshoot, MessageBoxButtons.YesNo);
                        switch (dialogResult)
                        {
                            case DialogResult.Yes:
                                return;
                            case DialogResult.No:
                                btnStop_Click(sender, e);
                                break;
                        }
                    }

                }
                if (_statusBarControl._minutes >= 59)
                {
                    _statusBarControl._hours++;
                    _statusBarControl._minutes = 0;
                }
            }

            lblTimer.Text = string.Format(StatusBarControl.AppendZero(_statusBarControl._hours) + ":" + StatusBarControl.AppendZero(_statusBarControl._minutes) + ":" + StatusBarControl.AppendZero(_statusBarControl._seconds));
        }

        private static void ExtractEmbeddedResource(string nameSpace, string outDirectory, string internalFilePath, string resourceName)
        {
            try
            {                
                var assembly = Assembly.GetCallingAssembly();

                using (var s = assembly.GetManifestResourceStream(nameSpace + "." + (internalFilePath == "" ? "" : internalFilePath + ".") + resourceName))
                    if (s != null)
                        using (var r = new BinaryReader(s))
                        using (var fs = new FileStream(outDirectory + "\\" + resourceName, FileMode.OpenOrCreate))
                        using (var w = new BinaryWriter(fs))
                            w.Write(r.ReadBytes((int)s.Length));
            }
            catch (Exception e)
            {
                _statusBarControl.GContext.LogMessage(e.Message);
            }
        }

        private static void RunOsvCInfo()
        {
            try
            {
                var proc = new Process
                {
                    StartInfo =
                    {
                        FileName = StatusBarControl._rootpath + "\\OSvCinfo.bat",
                        Arguments = StatusBarControl._osvcLoggedin + " " + StatusBarControl._osvcInterface + " " + StatusBarControl._hostname + " " + StatusBarControl._path + "\\" +
                                    DateTime.Now.ToString("MMddyyyyHHmmss") + "_OSvCInfo.txt",
                        WindowStyle = ProcessWindowStyle.Normal,
                        CreateNoWindow = true
                    }
                };
                proc.Start();
                proc.WaitForExit();

                CompressAndNotify();
            }
            catch (Exception e)
            {
                _statusBarControl.GContext.LogMessage(e.Message);
            }
        }

        private static void CompressAndNotify()
        {
            try
            {
                ZipFile.CreateFromDirectory(StatusBarControl._path, StatusBarControl._path + ".zip", CompressionLevel.Fastest, true);
                Directory.Delete(StatusBarControl._path, true);

                var strLocation = StatusBarControl._path + ".zip";

                using (var frm = new FrmCompletionForm(strLocation, Launcher.Finalnotification))
                {
                    frm.ShowDialog();
                }

            }
            catch (Exception e)
            {
                _statusBarControl.GContext.LogMessage(e.Message);
            }
        }

        private static void WorkStationInfo()
        {
            try
            {
                var compInfor = new Microsoft.VisualBasic.Devices.ComputerInfo();

                var ocsInfo = StatusBarControl._path + "\\" + DateTime.Now.ToString("MMddyyyyHHmmss") + "_OSvCInfo.txt";                

                using (var sw = File.CreateText(ocsInfo))
                {
                    var openSubKey = Registry.LocalMachine.OpenSubKey("hardware\\description\\system\\centralprocessor\\0");
                    if (openSubKey != null)

                        sw.WriteLine("-- Start Workstation Information --");
                    sw.WriteLine("OSvC Site Name: " + StatusBarControl._osvcInterface);
                    sw.WriteLine("Host Name: " + Environment.MachineName);
                    if (openSubKey != null) sw.WriteLine("Processor: " + openSubKey.GetValue("ProcessorNameString"));
                    sw.WriteLine("OS: " + compInfor.OSFullName);
                    sw.WriteLine("Available Physical Memory: " + compInfor.AvailablePhysicalMemory / 1024 / 1024 / 1024 + "GB");
                    sw.WriteLine("Available Virtual Memory: " + compInfor.AvailableVirtualMemory / 1024 / 1024 / 1024 + "GB");
                    sw.WriteLine("Total Physical Memory: " + compInfor.TotalPhysicalMemory / 1024 / 1024 / 1024 + "GB");
                    sw.WriteLine("Total Virtual Memory: " + compInfor.TotalVirtualMemory / 1024 / 1024 / 1024 + "GB");
                    sw.WriteLine("Total Processes Running: " + Process.GetProcesses().Length);
                    sw.WriteLine(".NET Framework Version: " + Get45PlusFromRegistry());
                    sw.WriteLine("-- End Workstation Information --");
                    sw.WriteLine(" ");
                    sw.WriteLine("\nNote: For more information on Workstation and Network Data, please run the OSCinfo.bat utility as published in Answer 2412 or enable the Add-In ServerProperty WorkstationInfo.");
                }
            }
            catch (Exception e)
            {
                _statusBarControl.GContext.LogMessage(e.Message);
            }
        }

        private static string Get45PlusFromRegistry()
        {
            const string subkey = @"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\";
            string version;

            using (var ndpKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32).OpenSubKey(subkey))
            {
                version = ndpKey?.GetValue("Release") != null ? CheckFor45PlusVersion((int)ndpKey.GetValue("Release")) : ".NET Framework Version 4.5 or later is not detected.";
            }

            return version;
        }

        private static string CheckFor45PlusVersion(int releaseKey)
        {
            if (releaseKey >= 460798)
                return "4.7 or later";
            if (releaseKey >= 394802)
                return "4.6.2";
            if (releaseKey >= 394254)
            {
                return "4.6.1";
            }
            if (releaseKey >= 393295)
            {
                return "4.6";
            }
            if (releaseKey >= 379893)
            {
                return "4.5.2";
            }
            if (releaseKey >= 378675)
            {
                return "4.5.1";
            }
            return releaseKey >= 378389 ? "4.5" : "No 4.5 or later version detected";
            // This code should never execute. A non-null release key should mean
            // that 4.5 or later is installed.
        }

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            _statusBarControl.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.StatusBarControlRef1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.StatusBarControlRef1.Location = new System.Drawing.Point(0, 0);
            this.label1.StatusBarControlRef1.Name = "label1";
            this.label1.StatusBarControlRef1.Size = new System.Drawing.Size(0, 13);
            this.label1.StatusBarControlRef1.TabIndex = 1;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.StatusBarControlRef1.Location = new System.Drawing.Point(101, 4);
            this.lblTimer.StatusBarControlRef1.Name = "lblTimer";
            this.lblTimer.StatusBarControlRef1.Size = new System.Drawing.Size(49, 13);
            this.lblTimer.StatusBarControlRef1.TabIndex = 5;
            this.lblTimer.Text = "00:00:00";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnStop
            // 
            this.btnStop.StatusBarControlRef1.Enabled = false;
            this.btnStop.FlatAppearance.BorderSize = 0;
            this.btnStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStop.Image = global::Troubleshoot_StatusBar.Properties.Resources.btnStop;
            this.btnStop.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnStop.StatusBarControlRef1.Location = new System.Drawing.Point(50, -1);
            this.btnStop.StatusBarControlRef1.Name = "btnStop";
            this.btnStop.StatusBarControlRef1.Size = new System.Drawing.Size(52, 22);
            this.btnStop.StatusBarControlRef1.TabIndex = 7;
            this.btnStop.Text = "Stop";
            this.btnStop.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.StatusBarControlRef1.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.FlatAppearance.BorderSize = 0;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Image = global::Troubleshoot_StatusBar.Properties.Resources.btnStart;
            this.btnStart.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnStart.StatusBarControlRef1.Location = new System.Drawing.Point(3, 0);
            this.btnStart.StatusBarControlRef1.Name = "btnStart";
            this.btnStart.StatusBarControlRef1.Size = new System.Drawing.Size(52, 20);
            this.btnStart.StatusBarControlRef1.TabIndex = 6;
            this.btnStart.Text = "Start";
            this.btnStart.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.StatusBarControlRef1.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // StatusBarControl
            // 
            _statusBarControl.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            _statusBarControl.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            _statusBarControl.Controls.Add(this.btnStop);
            _statusBarControl.Controls.Add(this.btnStart);
            _statusBarControl.Controls.Add(this.lblTimer);
            _statusBarControl.Controls.Add(this.label1);
            _statusBarControl.MinimumSize = new System.Drawing.Size(143, 23);
            _statusBarControl.Name = "StatusBarControl";
            _statusBarControl.Size = new System.Drawing.Size(196, 25);
            _statusBarControl.ResumeLayout(false);
            _statusBarControl.PerformLayout();

        }
    }
}